﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace myChampions
{

    // *************************************************************
    // Title: CommandList
    // Description: A list of interactive commands for the Finch robot
    // Application Type: Console
    // Author: Nolan Wurm
    // Dated Created: 11/8/18
    // Last Modified: 11/11/18
    // *************************************************************

    class Program
    {

        static void Main(string[] args)
        {
            DisplayOpeningScreen();
            DisplayMainMenu();
            DisplayChampList();
            DisplayGetMyTeam();
            DisplayTeamRanking();
            DisplayClosingScreen();            
        }

        static void DisplayMainMenu()
        {        

            {
                bool runApplication = true;
                string userMenuChoice;

                while (runApplication)
                {
                    DisplayHeader("Main Menu");
                    //Display Main Menu

                    Console.WriteLine("A) Connect to the Finch");
                    Console.WriteLine("B) Get Data Parameters");
                    Console.WriteLine("C) Acquire Data Set");
                    Console.WriteLine("D) Quit");
                    Console.WriteLine();
                    Console.Write("Enter Menu Choice: ");
                    userMenuChoice = Console.ReadLine().ToUpper();

                    //Process Menu Choice

                    switch (userMenuChoice)
                    {
                        case "A":
                            DisplayChampList();
                            break;
                        case "B":
                            DisplayGetMyTeam();
                            break;
                        case "C":
                            DisplayTeamRanking();
                            break;
                        case "D":
                            runApplication = false; break;
                        default:
                            Console.WriteLine();
                            Console.WriteLine("Please enter the letter for a menu choice.");

                            DisplayContinuePrompt();
                            break;
                    }
                }
            }
        }
        static void DisplayOpeningScreen()
        {
            
        }

        static void DisplayChampList()
        {
            //string dataPath = @Data\allChamps.txt;
            //Console.WriteLine(dataPath);
            Console.WriteLine("Captian America, Iron Man, Hulk, Thor, Vision");
            DisplayContinuePrompt();
        }

        static void DisplayGetMyTeam()
        {

        }

        static void DisplayTeamRanking()
        {

        }

        static void DisplayClosingScreen()
        {
            Console.Clear();
            Console.WriteLine();
            //Add aski for MARVEL COC or something
            Console.WriteLine();
            Console.WriteLine("\t\tThank You!");
            Console.WriteLine();
            DisplayContinuePrompt();
        }

        #region HELPER  METHODS

        /// <summary>
        /// display header
        /// </summary>
        /// <param name="header"></param>
        static void DisplayHeader(string header)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("\t\t" + header);
            Console.WriteLine();
        }

        /// <summary>
        /// display the continue prompt
        /// </summary>
        static void DisplayContinuePrompt()
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }

        #endregion

    }
}
